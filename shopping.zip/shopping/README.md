# NexusMarket - Multi-Vendor E-Commerce Platform

A modern, responsive multi-vendor online shopping web application featuring 3 dedicated dashboards (**Admin**, **Seller**, and **Buyer**), real-time inventory management, city-based location filtering, and testable accounts.

---

## 🚀 How to Run on macOS / MacBook

### 1. Requirements
Ensure Node.js (version 18 or later) is installed on your Mac. You can check by running:
```bash
node -v
npm -v
```

### 2. Installation & Running
Open your Terminal, navigate to this `shopping` folder, and run:

```bash
# Navigate to project folder
cd shopping

# Install dependencies (React 19, Vite, Lucide React icons)
npm install

# Start local development server
npm run dev
```

Open your browser at: **`http://localhost:5173/`**

---

## 🔑 Testable Demo Accounts (1-Click Login)
Click **"Sign In / Register"** or use the top helper bar in the app:
- 🛡️ **Platform Admin**: `admin@marketplace.com` / `password123`
- 🏪 **TechVault Seller (New York)**: `tech@marketplace.com` / `password123`
- 🏪 **Urban Craft Seller (Chicago)**: `urban@marketplace.com` / `password123`
- 🛍️ **Alex Johnson (Buyer, Austin)**: `buyer@marketplace.com` / `password123`

---

## 📁 Project Structure
- `src/components/`:
  - `AdminDashboard.jsx` (Platform revenue, global listing moderation, seller directory, master order log)
  - `SellerDashboard.jsx` (Store info, product CRUD, Mark as Sold Out toggle, customer shipping updates)
  - `BuyerDashboard.jsx` (Marketplace grid, city location filter, category filter, search bar, order tracker)
  - `Navbar.jsx`, `AuthModal.jsx`, `CartDrawer.jsx`, `ProductDetailModal.jsx`, `OrderTrackingModal.jsx`
- `src/context/StoreContext.jsx` (State engine & LocalStorage persistence)
- `src/data/initialData.js` (Seed dataset of accounts, products, and orders)
