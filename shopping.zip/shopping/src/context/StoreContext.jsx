import React, { createContext, useContext, useState, useEffect } from 'react';
import { INITIAL_USERS, INITIAL_PRODUCTS, INITIAL_ORDERS } from '../data/initialData';

const StoreContext = createContext();

export const StoreProvider = ({ children }) => {
  // Load state from localStorage or use seed data
  const [users, setUsers] = useState(() => {
    const saved = localStorage.getItem('nexus_shop_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [products, setProducts] = useState(() => {
    const saved = localStorage.getItem('nexus_shop_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem('nexus_shop_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [currentUser, setCurrentUser] = useState(() => {
    const saved = localStorage.getItem('nexus_shop_current_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[3]; // Default to Buyer account (Alex Johnson)
  });

  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('nexus_shop_cart');
    return saved ? JSON.parse(saved) : [];
  });

  // Filters
  const [selectedCity, setSelectedCity] = useState('All Cities');
  const [selectedCategory, setSelectedCategory] = useState('All Categories');
  const [searchQuery, setSearchQuery] = useState('');
  const [priceRange, setPriceRange] = useState([0, 1000]);
  const [showSoldOut, setShowSoldOut] = useState(true);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('nexus_shop_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('nexus_shop_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('nexus_shop_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('nexus_shop_current_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('nexus_shop_cart', JSON.stringify(cart));
  }, [cart]);

  // Auth Functions
  const login = (email, password) => {
    const found = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );
    if (found) {
      setCurrentUser(found);
      return { success: true, user: found };
    }
    return { success: false, message: 'Invalid email or password' };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const signup = (userData) => {
    // Check existing email
    const exists = users.some((u) => u.email.toLowerCase() === userData.email.toLowerCase());
    if (exists) {
      return { success: false, message: 'An account with this email already exists' };
    }

    const newUser = {
      id: `user-${Date.now()}`,
      name: userData.name,
      email: userData.email,
      password: userData.password,
      role: userData.role || 'buyer',
      city: userData.city || 'New York',
      storeName: userData.role === 'seller' ? userData.storeName || `${userData.name}'s Shop` : undefined,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(userData.name)}`,
      joinedDate: new Date().toISOString().split('T')[0]
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    return { success: true, user: newUser };
  };

  // Product Functions (Seller)
  const addProduct = (productData) => {
    if (!currentUser || currentUser.role !== 'seller') return;

    const newProduct = {
      id: `prod-${Date.now()}`,
      sellerId: currentUser.id,
      sellerName: currentUser.storeName || currentUser.name,
      sellerCity: currentUser.city || 'New York',
      title: productData.title,
      description: productData.description,
      price: parseFloat(productData.price),
      originalPrice: productData.originalPrice ? parseFloat(productData.originalPrice) : parseFloat(productData.price) * 1.2,
      category: productData.category,
      stock: parseInt(productData.stock, 10),
      isSoldOut: parseInt(productData.stock, 10) <= 0 || productData.isSoldOut,
      rating: 5.0,
      reviewsCount: 1,
      image: productData.image || 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&auto=format&fit=crop&q=80',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setProducts((prev) => [newProduct, ...prev]);
  };

  const updateProduct = (productId, updates) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const updatedStock = updates.stock !== undefined ? parseInt(updates.stock, 10) : p.stock;
          const isSoldOut = updates.isSoldOut !== undefined ? updates.isSoldOut : updatedStock <= 0;
          return {
            ...p,
            ...updates,
            stock: updatedStock,
            isSoldOut
          };
        }
        return p;
      })
    );
  };

  const deleteProduct = (productId) => {
    setProducts((prev) => prev.filter((p) => p.id !== productId));
    // Remove from cart if present
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const toggleSoldOut = (productId) => {
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const nextSoldOut = !p.isSoldOut;
          return {
            ...p,
            isSoldOut: nextSoldOut,
            stock: nextSoldOut ? 0 : (p.stock > 0 ? p.stock : 5)
          };
        }
        return p;
      })
    );
  };

  // Cart Functions
  const addToCart = (product, quantity = 1) => {
    if (product.isSoldOut || product.stock <= 0) return;

    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prev];
        const newQty = Math.min(product.stock, updated[existingIndex].quantity + quantity);
        updated[existingIndex] = { ...updated[existingIndex], quantity: newQty };
        return updated;
      }
      return [...prev, { product, quantity: Math.min(product.stock, quantity) }];
    });
  };

  const updateCartQuantity = (productId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => {
        if (item.product.id === productId) {
          const maxQty = item.product.stock > 0 ? item.product.stock : 1;
          return { ...item, quantity: Math.min(maxQty, quantity) };
        }
        return item;
      })
    );
  };

  const removeFromCart = (productId) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Order Functions
  const placeOrder = (shippingInfo) => {
    if (!currentUser || cart.length === 0) return null;

    const totalAmount = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

    const orderItems = cart.map((item) => ({
      id: `item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      productId: item.product.id,
      title: item.product.title,
      price: item.product.price,
      quantity: item.quantity,
      image: item.product.image,
      sellerId: item.product.sellerId,
      sellerName: item.product.sellerName,
      sellerCity: item.product.sellerCity,
      status: 'Processing',
      trackingNumber: null
    }));

    const newOrder = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      buyerId: currentUser.id,
      buyerName: currentUser.name,
      buyerEmail: currentUser.email,
      buyerAddress: shippingInfo?.address || '123 Market St, Austin, TX',
      buyerCity: shippingInfo?.city || currentUser.city || 'Austin',
      totalAmount,
      createdAt: new Date().toISOString(),
      paymentStatus: 'Paid',
      items: orderItems
    };

    // Update stock levels
    setProducts((prev) =>
      prev.map((p) => {
        const cartItem = cart.find((ci) => ci.product.id === p.id);
        if (cartItem) {
          const newStock = Math.max(0, p.stock - cartItem.quantity);
          return {
            ...p,
            stock: newStock,
            isSoldOut: newStock <= 0
          };
        }
        return p;
      })
    );

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const updateItemStatus = (orderId, itemId, newStatus, trackingNumber = null) => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          const updatedItems = ord.items.map((item) => {
            if (item.id === itemId || item.productId === itemId) {
              return {
                ...item,
                status: newStatus,
                trackingNumber: trackingNumber || item.trackingNumber
              };
            }
            return item;
          });
          return { ...ord, items: updatedItems };
        }
        return ord;
      })
    );
  };

  // Reset Demo Data helper
  const resetDemoData = () => {
    localStorage.removeItem('nexus_shop_users');
    localStorage.removeItem('nexus_shop_products');
    localStorage.removeItem('nexus_shop_orders');
    localStorage.removeItem('nexus_shop_current_user');
    localStorage.removeItem('nexus_shop_cart');
    setUsers(INITIAL_USERS);
    setProducts(INITIAL_PRODUCTS);
    setOrders(INITIAL_ORDERS);
    setCurrentUser(INITIAL_USERS[3]);
    setCart([]);
  };

  // Get active cities list from registered sellers + default popular cities
  const availableCities = Array.from(
    new Set(['All Cities', ...users.filter((u) => u.role === 'seller' && u.city).map((u) => u.city), ...products.map((p) => p.sellerCity)])
  );

  return (
    <StoreContext.Provider
      value={{
        users,
        products,
        orders,
        currentUser,
        cart,
        selectedCity,
        setSelectedCity,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        priceRange,
        setPriceRange,
        showSoldOut,
        setShowSoldOut,
        availableCities,
        login,
        logout,
        signup,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleSoldOut,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        placeOrder,
        updateItemStatus,
        resetDemoData
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => useContext(StoreContext);
