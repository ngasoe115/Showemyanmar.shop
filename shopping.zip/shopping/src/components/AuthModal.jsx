import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { X, UserCheck, Shield, Store, MapPin, Mail, Lock, Sparkles } from 'lucide-react';

export const AuthModal = ({ isOpen, onClose }) => {
  const { login, signup, users } = useStore();
  const [isSignup, setIsSignup] = useState(false);
  const [error, setError] = useState('');

  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Signup form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('buyer'); // 'buyer' or 'seller'
  const [storeName, setStoreName] = useState('');
  const [city, setCity] = useState('New York');

  if (!isOpen) return null;

  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setError('');
    const res = login(loginEmail, loginPassword);
    if (res.success) {
      onClose();
    } else {
      setError(res.message);
    }
  };

  const handleSignupSubmit = (e) => {
    e.preventDefault();
    setError('');
    if (role === 'seller' && (!storeName.trim() || !city.trim())) {
      setError('Sellers must provide a Store Name and City.');
      return;
    }

    const res = signup({ name, email, password, role, storeName, city });
    if (res.success) {
      onClose();
    } else {
      setError(res.message);
    }
  };

  const quickLogin = (userEmail, userPassword) => {
    setError('');
    const res = login(userEmail, userPassword);
    if (res.success) {
      onClose();
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '480px' }}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Sparkles size={20} color="var(--primary)" />
            <h3 className="modal-title">{isSignup ? 'Create Your Account' : 'Welcome Back'}</h3>
          </div>
          <button onClick={onClose} className="btn btn-secondary btn-icon">
            <X size={18} />
          </button>
        </div>

        {/* Auth Error Display */}
        {error && (
          <div style={{ padding: '10px 14px', background: 'var(--danger-bg)', color: 'var(--danger)', borderRadius: 'var(--radius-md)', fontSize: '0.85rem', marginBottom: '16px' }}>
            {error}
          </div>
        )}

        {!isSignup ? (
          /* LOGIN FORM */
          <form onSubmit={handleLoginSubmit}>
            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                required
                className="form-control"
                placeholder="name@example.com"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                required
                className="form-control"
                placeholder="••••••••"
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
              />
            </div>

            <button type="submit" className="btn btn-primary" style={{ width: '100%', marginBottom: '16px' }}>
              Sign In
            </button>

            {/* QUICK TEST ACCOUNTS SELECTOR */}
            <div style={{ marginTop: '20px', paddingTop: '16px', borderTop: '1px solid var(--border-color)' }}>
              <div style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--text-muted)', marginBottom: '10px' }}>
                ⚡ INSTANT DEMO ACCOUNTS (1-CLICK LOG IN):
              </div>
              <div className="demo-accounts-grid">
                <button
                  type="button"
                  onClick={() => quickLogin('admin@marketplace.com', 'password123')}
                  className="demo-account-btn"
                  style={{ borderColor: 'rgba(236, 72, 153, 0.4)' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', fontWeight: 700, color: '#ec4899' }}>
                    <Shield size={14} /> Admin Account
                  </div>
                  <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>Full Access</span>
                </button>

                <button
                  type="button"
                  onClick={() => quickLogin('tech@marketplace.com', 'password123')}
                  className="demo-account-btn"
                  style={{ borderColor: 'rgba(16, 185, 129, 0.4)' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', fontWeight: 700, color: '#10b981' }}>
                    <Store size={14} /> TechVault Seller
                  </div>
                  <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>City: New York</span>
                </button>

                <button
                  type="button"
                  onClick={() => quickLogin('urban@marketplace.com', 'password123')}
                  className="demo-account-btn"
                  style={{ borderColor: 'rgba(16, 185, 129, 0.4)' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', fontWeight: 700, color: '#10b981' }}>
                    <Store size={14} /> Urban Craft Seller
                  </div>
                  <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>City: Chicago</span>
                </button>

                <button
                  type="button"
                  onClick={() => quickLogin('buyer@marketplace.com', 'password123')}
                  className="demo-account-btn"
                  style={{ borderColor: 'rgba(59, 130, 246, 0.4)' }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.825rem', fontWeight: 700, color: '#3b82f6' }}>
                    <UserCheck size={14} /> Alex Buyer
                  </div>
                  <span style={{ fontSize: '0.725rem', color: 'var(--text-muted)' }}>City: Austin</span>
                </button>
              </div>
            </div>

            <div style={{ textAlign: 'center', marginTop: '16px', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => setIsSignup(true)}
                style={{ background: 'none', border: 'none', color: 'var(--primary)', fontWeight: 700, cursor: 'pointer' }}
              >
                Sign Up Now
              </button>
            </div>
          </form>
        ) : (
          /* SIGNUP FORM */
          <form onSubmit={handleSignupSubmit}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                required
                className="form-control"
                placeholder="Jane Doe"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Email Address</label>
              <input
                type="email"
                required
                className="form-control"
                placeholder="jane@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Password</label>
              <input
                type="password"
                required
                className="form-control"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>

            {/* Account Type Selection */}
            <div className="form-group">
              <label className="form-label">Account Type</label>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                <button
                  type="button"
                  className={`btn ${role === 'buyer' ? 'btn-primary' : 'btn-secondary'}`}
                  onClick={() => setRole('buyer')}
                >
                  🛍️ Buyer Profile
                </button>
                <button
                  type="button"
                  className={`btn ${role === 'seller' ? 'btn-primary' : 'btn-secondary'}`}
                  style={role === 'seller' ? { background: 'linear-gradient(135deg, #10b981 0%, #059669 100%)' } : {}}
                  onClick={() => setRole('seller')}
                >
                  🏪 Seller Profile
                </button>
              </div>
            </div>

            {/* SELLER SPECIFIC FIELDS: STORE NAME & CITY */}
            {role === 'seller' && (
              <div style={{ padding: '14px', background: 'rgba(16, 185, 129, 0.08)', borderRadius: 'var(--radius-md)', border: '1px solid rgba(16, 185, 129, 0.3)', marginBottom: '16px' }}>
                <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#10b981', marginBottom: '10px' }}>
                  🏪 Seller Store Setup
                </div>

                <div className="form-group">
                  <label className="form-label">Store / Shop Name</label>
                  <input
                    type="text"
                    required
                    className="form-control"
                    placeholder="e.g. Apex Tech Store"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                  />
                </div>

                <div className="form-group" style={{ marginBottom: 0 }}>
                  <label className="form-label">City Location (Used for Buyer Filtering)</label>
                  <input
                    type="text"
                    required
                    className="form-control"
                    placeholder="e.g. San Francisco, London, New York"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                  />
                </div>
              </div>
            )}

            <button type="submit" className="btn btn-primary" style={{ width: '100%', marginBottom: '16px' }}>
              Create Account
            </button>

            <div style={{ textAlign: 'center', fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Already have an account?{' '}
              <button
                type="button"
                onClick={() => setIsSignup(false)}
                style={{ background: 'none', border: 'none', color: 'var(--primary)', fontWeight: 700, cursor: 'pointer' }}
              >
                Sign In
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
